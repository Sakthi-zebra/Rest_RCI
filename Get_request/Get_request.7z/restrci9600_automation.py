"""
rest api automation: this automation code is for fx9600 series readers
author : vs6993
"""

import requests
import json 
import logging
from pytest import *
from configparser import ConfigParser


# con=ConfigParser()
# con['config']={
#     'protocal':'http',
#     'ip': '10.17.131.124'
#     }
# with open('setting.ini','w') as f:
#     con.write(f)



class rest:
    global ip
    ip = '10.17.129.57'
    url = "http://"+ip+'/restri'

    def __init__(self, url, ip):
        self.url=url
        self.ip=ip


