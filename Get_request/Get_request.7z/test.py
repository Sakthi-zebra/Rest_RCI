my_dict ={}
my_dict['name']="veeresh"
my_dict['age']=29

for k,l in my_dict.items():
    print(k , l)
