from flask import Flask
import json
import requests
from requests.auth import HTTPBasicAuth

"""
rest api automation: this automation code is for fx9600 series readers
author : vs6993
"""

ip="10.17.131.218"
url ="http://"+ip+"/restrci"
#url ="http://10.17.130.136:8083/v2/rtls/location_analytics/passthru"

header =[('Content-type', 'text/html'),('Content-Length', '4096')]

payload={"Cmd":"GetRZ", "ID":"2"}
payload=json.dumps(payload)
resp = requests.post(url, data = payload)
print(resp.status_code)
# print(resp.headers['content-type'])
# print(resp.headers)
print(resp.text)




