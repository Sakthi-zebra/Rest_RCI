import http.client

conn = http.client.HTTPConnection("10.17.131.124")
payload = '{"Cmd":"GetInfo","Fields":"All"}'
conn.request("POST", "/restrci", payload)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))
